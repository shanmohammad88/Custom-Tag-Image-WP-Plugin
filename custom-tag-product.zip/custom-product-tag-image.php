<?php
/**
 * Plugin Name: Custom Product Tag Image
 * Plugin URI: https://Shanhacking.blogspot.com
 * Description: Add custom images to WooCommerce product tags.
 * Version: 2.0
 * Author: Shan Mohammad
 * Author URI: https://Shanhacking.blogspot.com
 * License: GPL2
 */

// Add image upload field to add tag page
function add_tag_image_field() {
    ?>
    <div class="form-field">
        <label for="tag_image"><?php _e('Tag Image', 'custom-product-tag-image'); ?></label>
        <input type="text" name="tag_image" id="tag_image" value="" class="tag-image-field">
        <button class="upload_image_button button"><?php _e('Upload/Add image', 'custom-product-tag-image'); ?></button>
        <p class="description"><?php _e('Upload an image for this tag.', 'custom-product-tag-image'); ?></p>
    </div>
    <?php
}
add_action('product_tag_add_form_fields', 'add_tag_image_field', 10, 2);

// Add image upload field to edit tag page
function edit_tag_image_field($term) {
    $image = get_term_meta($term->term_id, 'tag_image', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="tag_image"><?php _e('Tag Image', 'custom-product-tag-image'); ?></label></th>
        <td>
            <input type="text" name="tag_image" id="tag_image" value="<?php echo esc_attr($image); ?>" class="tag-image-field">
            <button class="upload_image_button button"><?php _e('Upload/Add image', 'custom-product-tag-image'); ?></button>
            <p class="description"><?php _e('Upload an image for this tag.', 'custom-product-tag-image'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('product_tag_edit_form_fields', 'edit_tag_image_field', 10, 2);

// Save the Custom Field
function save_tag_image($term_id) {
    if (isset($_POST['tag_image'])) {
        update_term_meta($term_id, 'tag_image', sanitize_text_field($_POST['tag_image']));
    }
}
add_action('created_product_tag', 'save_tag_image', 10, 2);
add_action('edited_product_tag', 'save_tag_image', 10, 2);

// Display the Tag Image on the Frontend
function display_tag_image() {
    $terms = get_the_terms(get_the_ID(), 'product_tag');
    $alignment = get_option('custom_tag_image_alignment', 'center'); // Get the alignment option

    if ($terms && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $image = get_term_meta($term->term_id, 'tag_image', true);
            if ($image) {
                echo '<img src="' . esc_url($image) . '" alt="" class="custom-tag-image" style="display: block; margin: 0 auto; text-align: ' . esc_attr($alignment) . '; max-width: 150px; height: auto;" />';
            }
        }
    }
}

// Enqueue Media Uploader Script
function enqueue_media_uploader() {
    wp_enqueue_media();
    wp_enqueue_script('custom-tag-image-script', plugins_url('/js/custom-tag-image.js', __FILE__), array('jquery'), null, true);
}
add_action('admin_enqueue_scripts', 'enqueue_media_uploader');

// Add Settings Page to Admin Menu
function custom_tag_image_settings_menu() {
    add_submenu_page(
        'woocommerce',
        'Custom Tag Image Settings',
        'Tag Image Settings',
        'manage_options',
        'custom-tag-image-settings',
        'custom_tag_image_settings_page'
    );
}
add_action('admin_menu', 'custom_tag_image_settings_menu');

// Render the Settings Page
function custom_tag_image_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Custom Tag Image Settings', 'custom-product-tag-image'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_tag_image_settings_group');
            do_settings_sections('custom-tag-image-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register Settings
function custom_tag_image_settings_init() {
    register_setting('custom_tag_image_settings_group', 'custom_tag_image_display_location');
    register_setting('custom_tag_image_settings_group', 'custom_tag_image_alignment'); // Register alignment setting

    add_settings_section(
        'custom_tag_image_settings_section',
        __('Display Settings', 'custom-product-tag-image'),
        'custom_tag_image_settings_section_callback',
        'custom-tag-image-settings'
    );

    add_settings_field(
        'custom_tag_image_display_location',
        __('Display Location', 'custom-product-tag-image'),
        'custom_tag_image_display_location_render',
        'custom-tag-image-settings',
        'custom_tag_image_settings_section'
    );

    // Add a new field for image alignment
    add_settings_field(
        'custom_tag_image_alignment',
        __('Image Alignment', 'custom-product-tag-image'),
        'custom_tag_image_alignment_render',
        'custom-tag-image-settings',
        'custom_tag_image_settings_section'
    );
}
add_action('admin_init', 'custom_tag_image_settings_init');

// Callback for Settings Section
function custom_tag_image_settings_section_callback() {
    echo __('Choose where the tag image should be displayed and how it should be aligned on your WooCommerce site.', 'custom-product-tag-image');
}

// Render the Display Location Dropdown
function custom_tag_image_display_location_render() {
    $options = get_option('custom_tag_image_display_location', 'before_title');
    ?>
    <select name="custom_tag_image_display_location">
        <option value="before_title" <?php selected($options, 'before_title'); ?>>Before Product Title</option>
        <option value="after_title" <?php selected($options, 'after_title'); ?>>After Product Title</option>
        <option value="single_product" <?php selected($options, 'single_product'); ?>>Single Product Page</option>
    </select>
    <?php
}

// Render the Image Alignment Dropdown
function custom_tag_image_alignment_render() {
    $alignment = get_option('custom_tag_image_alignment', 'center');
    ?>
    <select name="custom_tag_image_alignment">
        <option value="left" <?php selected($alignment, 'left'); ?>>Left</option>
        <option value="center" <?php selected($alignment, 'center'); ?>>Center</option>
        <option value="right" <?php selected($alignment, 'right'); ?>>Right</option>
    </select>
    <?php
}

// Display the Tag Image Based on Settings
function display_tag_image_based_on_setting() {
    $location = get_option('custom_tag_image_display_location', 'before_title');

    // Remove the default action if it exists
    remove_action('woocommerce_before_shop_loop_item_title', 'display_tag_image');

    switch ($location) {
        case 'before_title':
            add_action('woocommerce_before_shop_loop_item_title', 'display_tag_image');
            break;
        case 'after_title':
            add_action('woocommerce_shop_loop_item_title', 'display_tag_image');
            break;
        case 'single_product':
            add_action('woocommerce_before_single_product_summary', 'display_tag_image');
            break;
    }
}
add_action('init', 'display_tag_image_based_on_setting');

